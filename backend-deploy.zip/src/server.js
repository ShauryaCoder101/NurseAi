// Main Server File
if (process.env.NODE_ENV !== 'production') {
require('dotenv').config();
}
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');

// Import routes
const authRoutes = require('./routes/authRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const transcriptRoutes = require('./routes/transcriptRoutes');
const audioRoutes = require('./routes/audioRoutes');
const benchmarkRoutes = require('./routes/benchmarkRoutes');
const patientRecordRoutes = require('./routes/patientRecordRoutes');
const doctorRoutes = require('./routes/doctorRoutes');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction && !process.env.JWT_SECRET) {
  console.error('❌ JWT_SECRET is required in production');
  process.exit(1);
}

// Middleware
const allowedOrigins = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

if (isProduction) {
  // Trust the ELB/NGINX proxy so rate limits use real client IPs
  app.set('trust proxy', 1);
}

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin || !isProduction) {
      return callback(null, true);
    }
    if (allowedOrigins.length === 0) {
      return callback(null, true);
    }
    if (allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error('Not allowed by CORS'));
  },
};

// Health check endpoint (before ALL middleware - ELB needs this)
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'NurseAI Backend API is running',
    timestamp: new Date().toISOString(),
  });
});

app.use('/benchmark', express.static(path.join(__dirname, 'public/benchmark')));
app.use('/metrics', express.static(path.join(__dirname, '../public/metrics')));
app.use('/benchmarkdata', express.static(path.join(__dirname, '../public/benchmarkdata')));
app.use('/verify/doctor/benchmarking', express.static(path.join(__dirname, '../public/doctor-benchmarking')));
app.use('/verify/doctor', express.static(path.join(__dirname, '../public/doctor')));
app.use('/', express.static(path.join(__dirname, 'public/site')));

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      mediaSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "https://fonts.googleapis.com"],
    },
  },
}));
app.use(cors(corsOptions)); // Enable CORS for frontend
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({extended: true})); // Parse URL-encoded bodies

// Serve uploaded audio files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/transcripts', transcriptRoutes);
app.use('/api/audio', audioRoutes);
app.use('/api/benchmark', benchmarkRoutes);
app.use('/api/patient-record', patientRecordRoutes);
app.use('/api/doctor', doctorRoutes);

// Public metrics API (no auth)
const dashboardMetrics = require('./controllers/dashboardMetricsController');
app.get('/api/metrics', dashboardMetrics.getPublicMetrics);

// Benchmark data upload API (no auth)
const benchmarkData = require('./controllers/benchmarkDataController');
app.post('/api/benchmarkdata/upload', benchmarkData.upload.array('audios', 50), benchmarkData.uploadBenchmarkData);
app.get('/api/benchmarkdata/status', benchmarkData.getBenchmarkStatus);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found',
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  if (err?.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      success: false,
      error: 'File too large.',
    });
  }
  if (err?.message?.includes('Invalid')) {
    return res.status(400).json({
      success: false,
      error: err.message,
    });
  }
  res.status(500).json({
    success: false,
    error: 'Internal server error',
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🚀 NurseAI Backend Server running on port ${PORT}`);
  console.log(`📡 API Base URL: http://localhost:${PORT}/api`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}\n`);
  if (!process.env.GEMINI_API_KEY) {
    console.warn('⚠️  GEMINI_API_KEY is NOT set');
  } else {
    console.log('✅ GEMINI_API_KEY loaded');
  }
  if (isProduction && !process.env.CORS_ORIGINS) {
    console.warn('⚠️  CORS_ORIGINS is not set; CORS will block all origins.');
  }
});

module.exports = app;
